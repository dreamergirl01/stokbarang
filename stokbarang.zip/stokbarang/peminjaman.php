<?php
require "function.php";
require "cek.php";

//get data
//ambil data total
$get1 = mysqli_query($conn, "select *from peminjaman");
$count1 = mysqli_num_rows($get1); //menghitung seluruh kolom

//ambil data peminjaman yang statusnya dipinjam
$get2 = mysqli_query($conn, "select *from peminjaman where status='Dipinjam'");
$count2 = mysqli_num_rows($get2); //menghitung seluruh kolom yang statusnya dipinjam

//ambil data peminjaman yang statusnya kembali
$get3 = mysqli_query($conn, "select *from peminjaman where status='Kembali'");
$count3 = mysqli_num_rows($get3); //menghitung seluruh kolom 
// var_dump($count3);die();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Peminjaman Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .zoomable {
            width: 100px;
        }

        .zoomable:hover {
            transform: scale(2.5);
            transition: 0.3s ease;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="index.php">Dreamers Lab</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#!">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Stok Barang
                        </a>
                        <a class="nav-link" href="masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Barang Masuk
                        </a>
                        <a class="nav-link" href="keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Barang Keluar
                        </a>
                        <a class="nav-link" href="peminjaman.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Peminjaman Barang
                        </a>
                        <a class="nav-link" href="admin.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Kelola Admin
                        </a>
                        <a class="dropdown-item" href="logout.php">Logout</a>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Peminjaman Barang</h1>
                    <div class="card mb-4">
                        <div class="card-header">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                                Tambah Data
                            </button>
                            <br>

                            <div class="row mt-4">
                                <div class="col">
                                    <div class="card bg-info text-white p-2">
                                        <h3>Total Data : <?= $count1 ?></h3>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="card bg-danger text-white p-2">
                                        <h3>Total Dipinjam : <?= $count2 ?></h3>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="card bg-success text-white p-2">
                                        <h3>Total Kembali : <?= $count3 ?></h3>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4" style="width:250px">
                                <div class="col">
                                    <form method="post" class="form-inline">
                                        <input type="date" name="tgl_mulai" class="form-control">
                                        <input type="date" name="tgl_selesai" class="form-control"> <br>
                                        <button type="submit" name="filter_tgl" class="btn btn-info">Filter</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table_responsive">
                                <div class="container mt-3">
                                    <table class="table table-bordered table-striped" style="border-style: solid;" id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Gambar</th>
                                                <th>Nama Barang</th>
                                                <th>Peminjam</th>
                                                <th>Jumlah</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            if (isset($_POST['filter_tgl'])) {
                                                $mulai = $_POST['tgl_mulai'];
                                                $selesai = $_POST['tgl_selesai'];

                                                if ($mulai = !null || $selesai = !null) {
                                                    // echo "tes";
                                                    $ambilsemuadatastok = mysqli_query($conn, "select *from peminjaman p, stok s where s.id_barang = p.id_barang
                                                    and tanggal BETWEEN '$mulai' and DATE_ADD('$selesai',INTERVAL 1 DAY) order by id_pinjam DESC");
                                                    // var_dump($ambilsemuadatastok);die()
                                                } else {
                                                    $ambilsemuadatastok = mysqli_query($conn, "select *from peminjaman p, stok s where s.id_barang = p.id_barang
                                                    order by id_pinjam DESC");
                                                }
                                            } else {
                                                $ambilsemuadatastok = mysqli_query($conn, "select *from peminjaman p, stok s where s.id_barang = p.id_barang
                                                order by id_pinjam DESC");
                                            }

                                            $no = 1;
                                            while ($data = mysqli_fetch_assoc($ambilsemuadatastok)) {
                                                $id_pinjam = $data['id_pinjam'];
                                                $ib = $data['id_barang'];
                                                $tanggal = $data['tanggal_pinjam'];
                                                $nama_barang = $data['nama_barang'];
                                                $penerima = $data['peminjam'];
                                                $qty = $data['qty'];
                                                $status = $data['status'];

                                                //cek ada gambar atau tidak
                                                $gambar = $data['gambar']; //ambil gambar
                                                if ($gambar === null) {
                                                    //jika tidak ada gambar
                                                    $img = 'No Photo';
                                                } else {
                                                    //jika ada gambar 
                                                    $img = '<img src="image/' . $gambar . '" class="zoomable">';
                                                }

                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td><?= $tanggal ?></td>
                                                    <td><?= $img ?></td>
                                                    <td><?= $nama_barang ?></td>
                                                    <td><?= $penerima ?></td>
                                                    <td><?= $qty ?></td>
                                                    <td><?= $status ?></td>
                                                    <td>
                                                    <?php
                                                        // cek status
                                                        if ($status == 'Dipinjam') {
                                                            echo '<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit' . $id_pinjam . '">
                                                            Selesai
                                                            </button>';
                                                        } else {
                                                            //jika statusnya bukan dipinjam (telah dikembalikan)
                                                            echo 'Barang telah kembali';
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>

                                        <!-- edit data -->
                                        <!-- The Modal -->
                                        <div class=" modal fade" id="edit<?= $id_pinjam ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">

                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Selesaikan</h4>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <form method="post">
                                                        <div class="modal-body">
                                                            Apakah barang ini sudah selesai dipinjam? <br> <br>
                                                            <input type="hidden" name="id_pinjam" value="<?=$id_pinjam?>">
                                                            <input type="hidden" name="id_barang" value="<?=$ib?>">
                                                            <button type="submit" name="barangkembali" class="btn btn-primary">Iya</button>
                                                        </div>
                                                    </form>


                                                </div>
                                            </div>
                                        </div>

                                    <?php } ?>
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <!-- The Modal -->
            <div class="modal fade" id="myModal">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Data Peminjaman</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <form method="post">
                                <select name="barangnya" class="form-control">
                                    <?php
                                    $ambilsemuadatanya = mysqli_query($conn, "select *from stok");
                                    while ($fetcharray = mysqli_fetch_array($ambilsemuadatanya)) {
                                        $namabarangnya = $fetcharray['nama_barang'];
                                        $idbarangnya = $fetcharray['id_barang'];
                                    ?>
                                        <option value="<?= $idbarangnya ?>"><?= $namabarangnya ?></option>
                                    <?php } ?>
                                </select><br>
                                <input type="number" name="qty" class="form-control" placeholder="quantity" required> <br>
                                <input type="text" name="penerima" class="form-control" placeholder="penerima" required><br>
                                <button type="submit" name="pinjam" class="btn btn-primary">Submit</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid px-4">
            <div class="d-flex align-items-center justify-content-between small">
                <div class="text-muted">Copyright &copy; Your Website 2022</div>
                <div>
                    <a href="#">Privacy Policy</a>
                    &middot;
                    <a href="#">Terms &amp; Conditions</a>
                </div>
            </div>
        </div>
    </footer>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

</html>
<?php
session_start();
//membuat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "stokbarang");

//menambah barang baru
if (isset($_POST['addnewbarang'])) {
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];

    //soal gambar
    $allowed_extension = array('png', 'jpg');
    $nama = $_FILES['file']['name']; //ngambil nama gambar
    $dot = explode('.', $nama);
    $ekstensi = strtolower(end($dot)); //ngambil ekstensinya
    $ukuran = $_FILES['file']['size']; //ngambil size filenya
    $file_tmp = $_FILES['file']['tmp_name']; //ngambil lokasi filenya

    //penamaan file --> enkripsi
    $image = md5(uniqid($nama, true) . time()) . '.' . $ekstensi; //menggabungkan nama file yang dienkripsi dengan ekstensinya 

    //validasi udah ada atau belum
    $cek = mysqli_query($conn, "select *from stok where nama_barang='$nama_barang'");
    $hitung = mysqli_num_rows($cek);

    if ($hitung < 1) {
        //jika belum ada

        //proses upload gambar 
        if (in_array($ekstensi, $allowed_extension) === true) {
            //validasi ukuran filenya
            if ($ukuran < 15000000) {
                move_uploaded_file($file_tmp, 'image/' . $image);
                $addtotable = mysqli_query($conn, "insert into stok(nama_barang, deskripsi, stok, gambar) 
                values ('$nama_barang', '$deskripsi', '$stok', '$image')");
                if ($addtotable) {
                    header("location:index.php");
                } else {
                    echo "gagal";
                    header("location:index.php");
                }
            } else {
                //kalau filenya lebih dari 15mb
                echo '
                <script>
                alert("ukuran terlalu besar");
                window.location.href="index.php";
                </script>';
            }
        } else {
            //kalau filenya tidak png/jpg
            echo '
            <script>
            alert("file harus png/jpg");
            window.location.href="index.php";
            </script>';
        }
    } else {
        //jika sudah ada
        echo '
    <script>
    alert("nama barang sudah terdaftar");
    window.location.href="index.php";
    </script>';
    }
}

//menambahkan barang masuk
if (isset($_POST['barangmasuk'])) {
    $barangnya = $_POST['barangnya'];
    $penerima = $_POST['penerima'];
    $qty = $_POST['qty'];

    $cekstoksekarang = mysqli_query($conn, "select *from stok where id_barang='$barangnya'");
    $ambildatanya = mysqli_fetch_array($cekstoksekarang);

    $stoksekarang = $ambildatanya['stok'];
    $tambahkanstoksekarangdenganquantity = $stoksekarang + $qty;

    $addtomasuk = mysqli_query($conn, "insert into masuk(id_barang,keterangan,qty) values('$barangnya','$penerima','$qty')");
    $updatestokmasuk = mysqli_query($conn, "update stok set stok='$tambahkanstoksekarangdenganquantity'where id_barang='$barangnya'");
    if ($addtomasuk && $updatestokmasuk) {
        header("location:masuk.php");
    } else {
        echo "gagal";
        header("location:masuk.php");
    }
}

//menambahkan barang keluar
if (isset($_POST['barangkeluar'])) {
    $barangnya = $_POST['barangnya'];
    $penerima = $_POST['penerima'];
    $qty = $_POST['qty'];

    $cekstoksekarang = mysqli_query($conn, "select *from stok stok where id_barang='$barangnya'");
    $ambildatanya = mysqli_fetch_array($cekstoksekarang);

    $stoksekarang = $ambildatanya['stok'];
    if ($stoksekarang >= $qty) {
        //kalau barangnya cukup
        $tambahkanstoksekarangdenganquantity = $stoksekarang - $qty;

        $addtokeluar = mysqli_query($conn, "insert into keluar(id_barang,penerima,qty) values('$barangnya','$penerima','$qty')");
        $updatestokmasuk = mysqli_query($conn, "update stok set stok='$tambahkanstoksekarangdenganquantity'where id_barang='$barangnya'");
        if ($addtokeluar && $updatestokmasuk) {
            header("location:keluar.php");
        } else {
            echo "gagal";
            header("location:keluar.php");
        }
    } else {
        //kalau barangnya gak cukup
        echo '<script>
        alert ("Stok saat ini tidak mencukupi");
        window.location.href="keluar.php";
        </script>';
    }
}

//update barang
if (isset($_POST['updatebarang'])) {
    $id_barang = $_POST['ib'];
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];

    //soal gambar
    $allowed_extension = array('png', 'jpg');
    $nama = $_FILES['file']['name']; //ngambil nama gambar
    $dot = explode('.', $nama);
    $ekstensi = strtolower(end($dot)); //ngambil ekstensinya
    $ukuran = $_FILES['file']['size']; //ngambil size filenya
    $file_tmp = $_FILES['file']['tmp_name']; //ngambil lokasi filenya

    //penamaan file --> enkripsi
    $image = md5(uniqid($nama, true) . time()) . '.' . $ekstensi; //menggabungkan nama file yang dienkripsi dengan ekstensinya 

    if ($ukuran == 0) {
        //jika tidak ingin upload
        $update = mysqli_query($conn, "update stok set nama_barang='$nama_barang', deskripsi='$deskripsi',
        where id_barang='$id_barang'");
        if ($update) {
            header('location:index.php');
        } else {
            echo 'Gagal';
            header('location:index.php');
        }
    } else {
        //jika ingin upload
        move_uploaded_file($file_tmp, 'image/' . $image);
        $update = mysqli_query($conn, "update stok set nama_barang='$nama_barang', deskripsi='$deskripsi', gambar='$image' 
        where id_barang='$id_barang'");
        if ($update) {
            header('location:index.php');
        } else {
            echo 'Gagal';
            header('location:index.php');
        }
    }
}

//hapus barang
if (isset($_POST['hapusbarang'])) {
    $id_barang = $_POST['ib']; //id barang

    $gambar = mysqli_query($conn, "select *from sto where id_barang='$id_barang'");
    $get = mysqli_fetch_array($gambar);
    $img = 'image/' . $get['gambar'];
    unlink($img);

    $hapus = mysqli_query($conn, "delete from stok where id_barang='$id_barang'");
    if ($hapus) {
        header("location:index.php");
    } else {
        header("location:index.php");
    }
}

//update barang masuk
if (isset($_POST['updatebarangmasuk'])) {
    $ib = $_POST['ib'];
    $ibm = $_POST['ibm'];
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['keterangan'];
    $qty = $_POST['qty'];

    $lihatstok = mysqli_query($conn, "select *from stok where id_barang='$ib'");
    $stoknya = mysqli_fetch_array($lihatstok);
    $stoksekarang = $stoknya['stok'];

    $qtyskrg = mysqli_query($conn, "select *from masuk where id_masuk='$ib'");
    $qtynya = mysqli_fetch_array($qtyskrg);
    $qtyskrg = $qtynya['qty'];

    if ($qty > $qtyskrg) {
        $selisih = $qty - $qtyskrg;
        $kurangin = $stoksekarang + $selisih;
        $kurangistoknya = mysqli_query($conn, "update stok set stok='$kurangin' where id_barang = '$ib'");
        $updatenya = mysqli_query($conn, "update masuk set qty ='$qty', keterangan = '$deskripsi' where id_masuk = '$ibm'");
        if ($kurangistoknya && $updatenya) {
            header("location:masuk.php");
        } else {
            echo 'Gagal';
            header("location:masuk.php");
        }
    } else {
        $selisih = $qtyskrg - $qty;
        $kurangin = $stoksekarang - $selisih;
        $kurangistoknya = mysqli_query($conn, "update stok set stok='$kurangin' where id_barang = '$ib'");
        $updatenya = mysqli_query($conn, "update masuk set qty ='$qty', keterangan = '$deskripsi' where id_masuk = '$ibm'");
        if ($kurangistoknya && $updatenya) {
            header("location:masuk.php");
        } else {
            echo 'Gagal';
            header("location:masuk.php");
        }
    }
}

//menghapus barang masuk
if (isset($_POST['hapusbarangmasuk'])) {
    $ib = $_POST['ib'];
    $ibm = $_POST['ibm'];
    $qty = $_POST['qty'];

    $getdatastok = mysqli_query($conn, "select *from stok where id_barang='$ib'");
    $data = mysqli_fetch_array($getdatastok);

    $selisih = $stok - $qty;

    $update = mysqli_query($conn, "update stok set stok='$selisih' where id_barang='$ib'");
    $hapusdata = mysqli_query($conn, "delete from masuk where id_masuk='$ibm'");

    if ($update && $hapusdata) {
        header('location:masuk.php');
    } else {
        echo 'Gagal';
        header('location:masuk.php');
    }
}

//mengubah barang keluar
if (isset($_POST['updatebarangkeluar'])) {
    $ib = $_POST['ib'];
    $idk = $_POST['idk'];
    $penerima = $_POST['penerima'];
    $qty = $_POST['qty']; //qty baru inputan user

    //mengambil stok barang untuk saat ini
    $lihatstok = mysqli_query($conn, "select *from stok where id_barang='$ib'");
    $stoknya = mysqli_fetch_array($lihatstok);
    $stoksekarang = $stoknya['stok'];

    //qty yang keluar saat ini
    $qtyskrg = mysqli_query($conn, "select *from keluar where id_keluar='$idk'");
    $qtynya = mysqli_fetch_array($qtyskrg);
    $qtyskrg = $qtynya['qty'];


    if ($qty > $qtyskrg) {
        $selisih = $qty - $qtyskrg;
        $kurangin = $stoksekarang - $selisih;

        if ($selisih <= $stoksekarang) {
            //stok cukup keluarin prosesnya
            $kurangistoknya = mysqli_query($conn, "update stok set stok='$kurangin' where id_barang = '$ib'");
            $updatenya = mysqli_query($conn, "update keluar set qty ='$qty', penerima = '$penerima' where id_keluar = '$idk'");
            if ($kurangistoknya && $updatenya) {
                header("location:keluar.php");
            } else {
                echo 'Gagal';
                header("location:keluar.php");
            }
        } else {
            //kalau stok tidak cukup keluarin alertnya
            echo '<script>
            alert("Stok tidak mencukupi");
            window.location.href="keluar.php";
            </script>';
        }
    } else {
        $selisih = $qtyskrg - $qty;
        $kurangin = $stoksekarang + $selisih;
        $kurangistoknya = mysqli_query($conn, "update stok set stok='$kurangin' where id_barang = '$ib'");
        $updatenya = mysqli_query($conn, "update keluar set qty ='$qty', penerima = '$penerima' where id_keluar = '$idk'");
        if ($kurangistoknya && $updatenya) {
            header("location:keluar.php");
        } else {
            echo 'Gagal';
            header("location:keluar.php");
        }
    }
}

//menghapus barang keluar
if (isset($_POST['hapusbarangkeluar'])) {
    $ib = $_POST['ib'];
    $ibm = $_POST['ibm'];
    $qty = $_POST['qty'];

    $getdatastok = mysqli_query($conn, "select *from stok where id_barang='$ib'");
    $data = mysqli_fetch_array($getdatastok);

    $selisih = $stok - $qty;

    $update = mysqli_query($conn, "update stok set stok='$selisih' where id_barang='$ib'");
    $hapusdata = mysqli_query($conn, "delete from keluar where id_keluar='$idk'");

    if ($update && $hapusdata) {
        header('location:keluar.php');
    } else {
        echo 'Gagal';
        header('location:keluar.php');
    }
}

//menambah admin baru 
if (isset($_POST['addadmin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $queryinsert = mysqli_query($conn, "insert into login (email,password) values ('$email','$password')");

    if ($queryinsert) {
        header("location:admin.php");
    } else {
        header("location:admin.php");
    }
}

// mengupdate / mengedit admin
if (isset($_POST['updateadmin'])) {
    $idnya = $_POST['idu'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $queryupdate = mysqli_query($conn, "update login set email='$email', password='$password' where id_user='$idnya'");

    if ($queryupdate) {
        header("location:admin.php");
    } else {
        header("location:admin.php");
    }
}

//hapus admin
if (isset($_POST['hapusadmin'])) {
    $id = $_POST['idu'];

    $queryhapus = mysqli_query($conn, "delete from login where id_user='$id'");

    if ($queryhapus) {
        header("location:admin.php");
    } else {
        header("location:admin.php");
    }
}

//meminjam barang
if (isset($_POST['pinjam'])) {
    $id_barang = $_POST['barangnya']; //mengambil id barangnya
    $qty = $_POST['qty']; //mengambil jumlah barangnya
    $penerima = $_POST['penerima']; //mengambil nama penerima

    //ambil stok sekarang
    $stok_saat_ini = mysqli_query($conn, "select *from stok where id_barang='$id_barang'");
    $stok_nya = mysqli_fetch_array($stok_saat_ini);
    $stok = $stok_nya['stok']; //ini valuenya

    //kurangin stoknya
    $new_stok = $stok - $qty;

    //mulai queri insert
    $insertpinjam = mysqli_query($conn, "insert into peminjaman(id_barang,qty,peminjam) values ('$id_barang','$qty','$penerima')");

    //mengurangi stok di tabel stok
    $kurangistok = mysqli_query($conn, "update stok set stok='$new_stok' where id_barang='$id_barang'");

    if ($insertpinjam && $kurangistok) {
        //jika berhasil
        echo '<script>
        alert ("Berhasil");
        window.location.href="peminjaman.php";
        </script>';
    } else {
        //jika gagal
        echo '<script>
        alert ("Gagal");
        window.location.href="peminjaman.php";
        </script>';
    }
}

//menyelesaikan pinjaman
if (isset($_POST['barangkembali'])) {
    $id_pinjam = $_POST['id_pinjam'];
    $ib = $_POST['id_barang'];

    //eksekusi
    $update_status = mysqli_query($conn, "update peminjaman set status='Kembali' where id_pinjam='$id_pinjam'");

    //ambil stok sekarang
    $stok_saat_ini = mysqli_query($conn, "select *from stok where id_barang='$ib'");
    $stok_nya = mysqli_fetch_array($stok_saat_ini);
    $stok = $stok_nya['stok']; //ini valuenya

    //ambil qty dari si id_pinjam sekarang
    $qty_saat_ini1 = mysqli_query($conn, "select *from peminjaman where id_pinjam='$id_pinjam'");
    $stok_qty1 = mysqli_fetch_array($qty_saat_ini1);
    $stok1 = $stok_qty1['qty']; //ini valuenya

    //kurangin stoknya
    $new_stok = $stok1 + $stok;

    //kembalikan stoknya
    $kembalikanstok = mysqli_query($conn, "update stok set stok='$new_stok' where id_barang='$ib'"); 

    if ($update_status && $kembalikanstok) {
        //jika berhasil
        echo '<script>
        alert ("Berhasil");
        window.location.href="peminjaman.php";
        </script>';
    } else {
        //jika gagal
        echo '<script>
        alert ("Gagal");
        window.location.href="peminjaman.php";
        </script>';
    }
}
